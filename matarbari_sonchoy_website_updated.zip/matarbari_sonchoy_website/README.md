# মাতারবাড়ী সঞ্চয় ও ঐক্য সংঘ — ওয়েবসাইট

## ফাইল
- `index.html` — ওয়েব অ্যাপ
- `schema.sql` — Supabase ডাটাবেস টেবিল ও নীতিমালা তৈরির SQL

## Supabase সংযোগ
1. `index.html` HTTPS-এ হোস্ট করুন (যেমন GitHub Pages বা অন্য static hosting)।
2. Supabase Project URL এবং Publishable key ওয়েবসাইটের সংযোগ ফর্মে দিন। Publishable key ব্রাউজারে ব্যবহার করা যায়; Secret বা service_role key কখনো দেবেন না।
3. Supabase Dashboard → Authentication → URL Configuration-এ আপনার HTTPS ওয়েবসাইটের URL-টি Site URL এবং Redirect URLs-এ যোগ করুন।

## পাসওয়ার্ড ভুলে গেলে
লগইন পেজে সদস্য নিজের নিবন্ধিত ইমেইল লিখে “পাসওয়ার্ড ভুলে গেছেন?” চাপবে। Supabase থেকে পাঠানো ইমেইলের লিংক খুলে নতুন পাসওয়ার্ড সেট করবে। ইমেইল রিসেট ঠিকভাবে কাজ করতে HTTPS-এ হোস্ট করা URL-টি Supabase-এর Site URL/Redirect URLs-এ যোগ করা আবশ্যক। স্থানীয় `content://` ফাইল-ভিউ থেকে ইমেইল রিসেট লিংক ফেরত আসবে না।

## গুরুত্বপূর্ণ
এটি একটি প্রাথমিক হিসাব ব্যবস্থাপনা নমুনা; বাস্তব অর্থ লেনদেনের জন্য ব্যবহারের আগে RLS নীতি, হিসাবের নির্ভুলতা, ব্যাকআপ ও অ্যাক্সেস নিয়ন্ত্রণ ভালোভাবে পরীক্ষা করুন।
