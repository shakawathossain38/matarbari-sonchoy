create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'member' check (role in ('member','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.transactions (
  id uuid primary key default gen_random_uuid(),
  member_id uuid not null references public.profiles(id) on delete cascade,
  amount numeric(12,2) not null,
  transaction_type text not null,
  description text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean language sql stable security definer
set search_path = public
as $$ select exists(select 1 from public.profiles where id = auth.uid() and role = 'admin'); $$;

alter table public.profiles enable row level security;
alter table public.transactions enable row level security;

drop policy if exists "read own profile or admin" on public.profiles;
create policy "read own profile or admin" on public.profiles for select
using (id = auth.uid() or public.is_admin());

drop policy if exists "admin manages profiles" on public.profiles;
create policy "admin manages profiles" on public.profiles for all
using (public.is_admin()) with check (public.is_admin());

drop policy if exists "members read own transactions or admin" on public.transactions;
create policy "members read own transactions or admin" on public.transactions for select
using (member_id = auth.uid() or public.is_admin());

drop policy if exists "admin inserts transactions" on public.transactions;
create policy "admin inserts transactions" on public.transactions for insert
with check (public.is_admin() and created_by = auth.uid());

drop policy if exists "admin updates transactions" on public.transactions;
create policy "admin updates transactions" on public.transactions for update
using (public.is_admin()) with check (public.is_admin());

drop policy if exists "admin deletes transactions" on public.transactions;
create policy "admin deletes transactions" on public.transactions for delete
using (public.is_admin());
